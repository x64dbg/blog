// trace_overflow.c
// A tiny crash-investigation demo for x64dbg trace dump and trace xrefs.
// Build: clang.exe -O0 -gcodeview -fuse-ld=lld -Xlinker -debug -Xlinker -dynamicbase:no -Xlinker -highentropyva:no -o trace_overflow.exe trace_overflow.c

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

#if defined(_MSC_VER) || defined(__clang__)
#define NOINLINE __declspec(noinline)
#define EXPORT __declspec(dllexport)
#else
#define NOINLINE __attribute__((noinline))
#define EXPORT
#endif

typedef void (*Callback)(void);

typedef struct Arena {
    char overflow[16];
    char greeting[16];
    Callback callback;
    char scratch[8];
} Arena;

static Arena g_arena;

EXPORT NOINLINE void trace_begin(void)
{
    // Set a breakpoint here in x64dbg, then start Trace Into.
    // The access violation stops the trace; this demo does not need trace_end.
}

NOINLINE void safe_callback(void)
{
    puts("safe callback");
}

NOINLINE void zero_arena(Arena *arena)
{
    volatile uint8_t *p = (volatile uint8_t *)arena;
    size_t i;
    for (i = 0; i < sizeof(*arena); i++)
        p[i] = 0;
}

NOINLINE void copy_unbounded(char *dst, const char *src)
{
    while ((*dst++ = *src++) != 0) {
        // Deliberately no bounds check.
    }
}

NOINLINE void call_callback(void)
{
    g_arena.callback();
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    zero_arena(&g_arena);
    copy_unbounded(g_arena.greeting, "Hello!");
    g_arena.callback = safe_callback;

    printf("trace_overflow: crash after a buffer overflow\n");
    printf("  overflow buffer: %p (16 bytes)\n", (void *)g_arena.overflow);
    printf("  greeting buffer: %p (16 bytes)\n", (void *)g_arena.greeting);
    printf("  callback field:  %p (8 bytes)\n", (void *)&g_arena.callback);
    printf("  callback value:  %p\n", (void *)g_arena.callback);
    printf("  greeting before overflow: %s\n", g_arena.greeting);
    printf("Set a breakpoint on trace_begin, then trace until the access violation.\n");

    trace_begin();

    copy_unbounded(g_arena.overflow,
        "AAAAAAAAAAAAAAAA"
        "greeting_is_gone"
        "CCCCCCCC");

    call_callback();

    return 0;
}
