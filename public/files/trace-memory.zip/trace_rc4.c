// trace_rc4.c
// A tiny crackme for x64dbg trace dump, trace xrefs, and trace pattern search.
// Build: clang.exe -O0 -gcodeview -fuse-ld=lld -Xlinker -debug -Xlinker -dynamicbase:no -Xlinker -highentropyva:no -o trace_rc4.exe trace_rc4.c

#include <stdint.h>
#include <stdio.h>
#include <stddef.h>

#if defined(_MSC_VER) || defined(__clang__)
#define NOINLINE __declspec(noinline)
#define EXPORT __declspec(dllexport)
#else
#define NOINLINE __attribute__((noinline))
#define EXPORT
#endif

#define SECRET_LEN 20

// Encrypted RC4 output for the plaintext serial used by this demo.
// The plaintext does not appear as a string in the executable.
static const uint8_t encrypted_serial[SECRET_LEN] = {
    0x7F, 0x20, 0xC2, 0xBC, 0xB3, 0xF4, 0x87, 0x9F, 0xFE, 0xA6,
    0x06, 0x34, 0x6E, 0x18, 0x62, 0x54, 0x42, 0xC4, 0x73, 0x27
};

static const uint8_t rc4_key[] = "x64dbg-trace-demo";

EXPORT NOINLINE void trace_begin(void)
{
    // Set a breakpoint here in x64dbg, then start Trace Into.
}

EXPORT NOINLINE void trace_end(void)
{
    // Set a breakpoint here in x64dbg, so tracing stops after the demo.
}

NOINLINE void rc4_init(uint8_t s[256], const uint8_t *key, size_t key_len)
{
    uint32_t i;
    uint8_t j = 0;

    for (i = 0; i < 256; i++)
        s[i] = (uint8_t)i;

    for (i = 0; i < 256; i++) {
        uint8_t tmp;
        j = (uint8_t)(j + s[i] + key[i % key_len]);
        tmp = s[i];
        s[i] = s[j];
        s[j] = tmp;
    }
}

NOINLINE void rc4_crypt(uint8_t s[256], const uint8_t *input, uint8_t *output, size_t len)
{
    size_t n;
    uint8_t i = 0;
    uint8_t j = 0;

    for (n = 0; n < len; n++) {
        uint8_t tmp;
        uint8_t k;

        i = (uint8_t)(i + 1);
        j = (uint8_t)(j + s[i]);

        tmp = s[i];
        s[i] = s[j];
        s[j] = tmp;

        k = s[(uint8_t)(s[i] + s[j])];
        output[n] = (uint8_t)(input[n] ^ k);
    }
}

NOINLINE size_t bounded_strlen(const char *s, size_t max_len)
{
    size_t n = 0;
    while (n <= max_len && s[n] != 0)
        n++;
    return n;
}

NOINLINE int slow_equals(const char *user, const uint8_t *expected, size_t expected_len)
{
    size_t i;
    size_t user_len = bounded_strlen(user, expected_len);
    uint8_t diff = 0;

    for (i = 0; i < expected_len; i++) {
        uint8_t c = 0;
        if (i < user_len)
            c = (uint8_t)user[i];
        diff |= (uint8_t)(c ^ expected[i]);
    }

    return diff == 0 && user_len == expected_len;
}

NOINLINE void wipe_bytes(void *ptr, size_t len)
{
    volatile uint8_t *p = (volatile uint8_t *)ptr;
    size_t i;
    for (i = 0; i < len; i++)
        p[i] = 0;
}

int main(int argc, char **argv)
{
    uint8_t s[256];
    uint8_t expected[SECRET_LEN + 1];
    const char *user = argc > 1 ? argv[1] : "wrong";
    int ok;
    size_t i;

    for (i = 0; i < sizeof(expected); i++)
        expected[i] = 0;

    printf("trace_rc4: hidden serial check\n");
    printf("  S table:         %p (256 bytes)\n", (void *)s);
    printf("  expected serial: %p (%u bytes)\n", (void *)expected, (unsigned)SECRET_LEN);
    printf("  user input:      %s\n", user);
    printf("Set breakpoints on trace_begin and trace_end, then trace from trace_begin.\n");

    trace_begin();

    rc4_init(s, rc4_key, sizeof(rc4_key) - 1);
    rc4_crypt(s, encrypted_serial, expected, SECRET_LEN);
    expected[SECRET_LEN] = 0;

    ok = slow_equals(user, expected, SECRET_LEN);

    wipe_bytes(expected, sizeof(expected));
    wipe_bytes(s, 256);

    trace_end();

    puts(ok ? "correct" : "wrong");
    return ok ? 0 : 1;
}
