# x64dbg trace-memory crackmes

These programs are small inputs for the trace dump, trace Xref, and trace pattern-search features.

## Build

From this directory in Git Bash:

```sh
mkdir -p build
"/c/Program Files/LLVM/bin/clang.exe" -O0 -gcodeview -fuse-ld=lld -Xlinker -debug -Xlinker -dynamicbase:no -Xlinker -highentropyva:no -o build/trace_rc4.exe trace_rc4.c
"/c/Program Files/LLVM/bin/clang.exe" -O0 -gcodeview -fuse-ld=lld -Xlinker -debug -Xlinker -dynamicbase:no -Xlinker -highentropyva:no -o build/trace_overflow.exe trace_overflow.c
```

The linker flags `-dynamicbase:no -highentropyva:no` are the lld-link equivalents of `/DYNAMICBASE:NO /HIGHENTROPYVA:NO`. They keep module addresses stable across runs.

The examples export marker functions for convenient breakpoints. `trace_rc4.exe` uses `trace_begin` and `trace_end`. `trace_overflow.exe` uses only `trace_begin`; the access violation stops the trace.

## Example 1: `trace_rc4.exe`

Correct serial:

```text
x64dbg{trace-memory}
```

Suggested run:

```bat
trace_rc4.exe wrong
```

Trace workflow:

1. Open `trace_rc4.exe` in x64dbg.
2. Set the command line to `trace_rc4.exe wrong` if needed.
3. Open the Symbols view for the main module.
4. Set breakpoints on the exported functions `trace_begin` and `trace_end`.
5. Run to `trace_begin`.
6. Start `Trace into` from `trace_begin`.
7. The trace stops when `trace_end` is reached.
8. Open the Trace view, select the last traced instruction, and load the trace dump if x64dbg has not loaded it automatically.

Things to show:

- The console prints the stack addresses of `S` and `expected`.
- In the trace dump, go to the `expected` address and step through the trace rows around `rc4_crypt`; the buffer changes into the plaintext serial.
- Search the trace dump for this ASCII pattern:

```text
78 36 34 64 62 67 7B
```

That is the byte pattern for `x64dbg{`. It is not stored as plaintext in the program; it appears only after the RC4 decrypt loop writes it.

- Search for this RC4 initialization pattern:

```text
00 01 02 03 04 05 06 07
```

The result points at the temporary `S[256]` table created during `rc4_init`.

- Select a byte in the `expected` buffer and use the trace dump `Xref` action. The useful references are the RC4 write, the compare read, and the wipe write.

## Example 2: `trace_overflow.exe`

Trace workflow:

1. Open `trace_overflow.exe` in x64dbg.
2. Set a breakpoint on the exported function `trace_begin`.
3. Run to `trace_begin`.
4. Start `Trace into` from `trace_begin`. Set the max trace count to `100000` if x64dbg asks.
5. The trace stops on the access violation caused by `call_callback`.
6. Open the Trace view, select the last trace row, and load the trace dump if needed.

Things to show:

- The console prints the addresses of `overflow`, `greeting`, and the `callback` field.
- The crash happens because `g_arena.callback` was overwritten with `43 43 43 43 43 43 43 43`, the ASCII bytes for `CCCCCCCC`.
- In the trace dump, go to the printed `callback` field address, select the first byte, and use the trace dump `Xref` action.
- Jump to the last write before the crash. It lands inside `copy_unbounded(g_arena.overflow, ...)`, after the copy has crossed the end of `overflow`.
- Repeat the same action on the printed `greeting` address. Its bytes changed to `greeting_is_gone`, showing that the same overflow corrupted neighboring data before it corrupted the function pointer.

This is the cleanest motivating example for trace Xref: it answers "who last wrote the byte that caused this crash?" without needing a hardware breakpoint before the bug happens.
